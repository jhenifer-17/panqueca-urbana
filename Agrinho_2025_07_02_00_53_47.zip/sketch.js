let customers = [];
let fruits = [];
let farmer;
let money = 0;
let day = 1;
let sales = 0;

function setup() {
  createCanvas(800, 600);
  
  // Criar o fazendeiro
  farmer = {
    x: 150,
    y: 400,
    mood: 'happy',
    stock: {
      apples: 10,
      oranges: 8,
      grapes: 15,
      watermelons: 3
    },
    prices: {
      apples: 2,
      oranges: 3,
      grapes: 4,
      watermelons: 10
    }
  };
  
  // Criar alguns clientes iniciais
  for (let i = 0; i < 3; i++) {
    addCustomer();
  }
  
  // Criar estoque visual de frutas
  createFruitDisplay();
}

function draw() {
  // Fundo cênico rural
  drawBackground();
  
  // Desenhar elementos estáticos
  drawFarmersStand();
  drawRoad();
  drawFarm();
  
  // Desenhar elementos dinâmicos
  drawFarmer();
  drawCustomers();
  drawFruits();
  drawUI();
  
  // Mover clientes periodicamente
  if (frameCount % 120 === 0) {
    moveCustomers();
  }
  
  // Adicionar novos clientes ocasionalmente
  if (frameCount % 300 === 0 && customers.length < 5) {
    addCustomer();
  }
}

function drawBackground() {
  // Céu gradiente
  for (let y = 0; y < height/2; y++) {
    let inter = map(y, 0, height/2, 0, 1);
    let c = lerpColor(color(100, 180, 255), color(200, 230, 255), inter);
    stroke(c);
    line(0, y, width, y);
  }
  
  // Campo verde
  fill(50, 150, 50);
  noStroke();
  rect(0, height/2, width, height/2);
  
  // Sol
  fill(255, 255, 0);
  noStroke();
  circle(700, 100, 80);
}

function drawFarmersStand() {
  // Barraca do fazendeiro
  fill(150, 75, 0);
  rect(50, 350, 200, 200);
  
  // Teto da barraca
  fill(200, 100, 50);
  quad(50, 350, 250, 350, 300, 300, 0, 300);
  
  // Placa
  fill(255);
  rect(100, 320, 100, 30);
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("Frutas Frescas", 150, 340);
}

function drawRoad() {
  // Estrada para a cidade
  fill(100);
  rect(300, 300, 500, 200);
  
  // Linhas da estrada
  fill(255, 255, 0);
  for (let y = 350; y < 500; y += 50) {
    rect(500, y, 100, 20);
  }
}

function drawFarm() {
  // Fazenda ao fundo
  fill(150, 75, 0);
  rect(650, 250, 100, 100);
  
  // Telhado
  fill(100, 50, 0);
  triangle(650, 250, 750, 250, 700, 200);
  
  // Árvores
  fill(50, 100, 0);
  ellipse(600, 200, 50, 80);
  ellipse(550, 220, 60, 90);
}

function drawFarmer() {
  // Corpo do fazendeiro
  fill(210, 180, 140);
  rect(farmer.x, farmer.y, 50, 100);
  
  // Cabeça
  fill(240, 200, 150);
  circle(farmer.x+25, farmer.y-30, 60);
  
  // Chapéu
  fill(150, 75, 0);
  arc(farmer.x+25, farmer.y-50, 70, 40, PI, TWO_PI);
  
  // Expressão facial
  fill(0);
  if (farmer.mood === 'happy') {
    arc(farmer.x+25, farmer.y-20, 30, 20, 0, PI); // sorriso
  } else {
    arc(farmer.x+25, farmer.y-15, 30, 20, PI, TWO_PI); // carranca
  }
  
  // Olhos
  ellipse(farmer.x+15, farmer.y-35, 10, 5);
  ellipse(farmer.x+35, farmer.y-35, 10, 5);
}

function drawCustomers() {
  for (let i = 0; i < customers.length; i++) {
    let c = customers[i];
    
    // Corpo do cliente
    fill(c.color);
    rect(c.x, c.y, 40, 80);
    
    // Cabeça
    fill(240, 200, 150);
    circle(c.x+20, c.y-20, 50);
    
    // Expressão
    fill(0);
    if (c.bought) {
      arc(c.x+20, c.y-5, 30, 20, 0, PI); // feliz
    } else {
      line(c.x+10, c.y-5, c.x+30, c.y-5); // neutro
    }
    
    // Olhos
    ellipse(c.x+12, c.y-25, 8, 4);
    ellipse(c.x+28, c.y-25, 8, 4);
    
    // Bolsa (se comprou)
    if (c.bought) {
      fill(200, 150, 0);
      rect(c.x+5, c.y+20, 30, 20);
      // Fruta comprada
      fill(c.fruitColor);
      circle(c.x+20, c.y+30, 15);
    }
    
    // Balão de pensamento
    if (!c.bought && frameCount % 120 < 60) {
      fill(255);
      rect(c.x+50, c.y-50, 80, 40, 10);
      fill(0);
      textSize(12);
      text(c.desiredFruit, c.x+90, c.y-30);
    }
  }
}

function createFruitDisplay() {
  // Posições das frutas na barraca
  const fruitPositions = [
    {x: 80, y: 400, type: 'apples', color: color(255, 50, 50)},
    {x: 150, y: 400, type: 'oranges', color: color(255, 165, 0)},
    {x: 80, y: 470, type: 'grapes', color: color(150, 50, 150)},
    {x: 150, y: 470, type: 'watermelons', color: color(50, 150, 50)}
  ];
  
  for (let fp of fruitPositions) {
    fruits.push({
      x: fp.x,
      y: fp.y,
      type: fp.type,
      color: fp.color,
      amount: farmer.stock[fp.type]
    });
  }
}

function drawFruits() {
  for (let fruit of fruits) {
    // Desenhar a fruta
    fill(fruit.color);
    
    switch(fruit.type) {
      case 'apples':
        for (let i = 0; i < min(5, fruit.amount); i++) {
          circle(fruit.x + i*15, fruit.y, 20);
        }
        break;
      case 'oranges':
        for (let i = 0; i < min(5, fruit.amount); i++) {
          circle(fruit.x + i*15, fruit.y, 20);
        }
        break;
      case 'grapes':
        for (let i = 0; i < min(5, fruit.amount); i++) {
          circle(fruit.x + i*10, fruit.y + (i%2)*10, 15);
        }
        break;
      case 'watermelons':
        for (let i = 0; i < min(2, fruit.amount); i++) {
          ellipse(fruit.x + i*40, fruit.y, 30, 25);
          stroke(0);
          line(fruit.x + i*40 - 15, fruit.y, fruit.x + i*40 + 15, fruit.y);
          noStroke();
        }
        break;
    }
    
    // Mostrar quantidade restante
    fill(0);
    textSize(12);
    text(`${fruit.type}: ${farmer.stock[fruit.type]}`, fruit.x, fruit.y - 10);
    text(`$${farmer.prices[fruit.type]}`, fruit.x, fruit.y + 25);
  }
}

function drawUI() {
  // Painel de informações
  fill(255, 230);
  rect(10, 10, 200, 80, 10);
  
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text(`Dia: ${day}`, 20, 30);
  text(`Vendas: ${sales}`, 20, 50);
  text(`Dinheiro: $${money}`, 20, 70);
  
  // Botão para próximo dia
  fill(100, 200, 100);
  rect(600, 20, 150, 40, 5);
  fill(255);
  textAlign(CENTER);
  text("Próximo Dia", 675, 45);
}

function addCustomer() {
  let customerTypes = [
    {color: color(200, 200, 255), desiredFruit: 'apples'},
    {color: color(255, 200, 200), desiredFruit: 'oranges'},
    {color: color(200, 255, 200), desiredFruit: 'grapes'},
    {color: color(255, 255, 200), desiredFruit: 'watermelons'}
  ];
  
  let type = random(customerTypes);
  customers.push({
    x: 400 + random(300),
    y: 400,
    color: type.color,
    desiredFruit: type.desiredFruit,
    bought: false,
    fruitColor: type.desiredFruit === 'apples' ? color(255, 50, 50) :
                type.desiredFruit === 'oranges' ? color(255, 165, 0) :
                type.desiredFruit === 'grapes' ? color(150, 50, 150) : color(50, 150, 50),
    speed: random(1, 3)
  });
}

function moveCustomers() {
  for (let i = customers.length - 1; i >= 0; i--) {
    let c = customers[i];
    
    if (!c.bought) {
      // Movimento em direção à barraca
      if (c.x > 300) {
        c.x -= c.speed;
      } else {
        // Tentar comprar
        if (farmer.stock[c.desiredFruit] > 0) {
          // Venda bem-sucedida
          farmer.stock[c.desiredFruit]--;
          money += farmer.prices[c.desiredFruit];
          sales++;
          c.bought = true;
          farmer.mood = 'happy';
        } else {
          // Sem estoque
          farmer.mood = 'angry';
        }
      }
    } else {
      // Cliente satisfeito indo embora
      c.x += c.speed;
      if (c.x > width) {
        customers.splice(i, 1);
      }
    }
  }
}

function mousePressed() {
  // Verificar clique no botão "Próximo Dia"
  if (mouseX > 600 && mouseX < 750 && mouseY > 20 && mouseY < 60) {
    nextDay();
  }
  
  // Verificar clique nas frutas para reabastecer (com custo)
  for (let fruit of fruits) {
    if (dist(mouseX, mouseY, fruit.x, fruit.y) < 30 && money >= 10) {
      farmer.stock[fruit.type] += 5;
      money -= 10;
    }
  }
}

function nextDay() {
  day++;
  sales = 0;
  farmer.mood = 'happy';
  
  // Reabastecer estoque parcialmente
  farmer.stock.apples += 2;
  farmer.stock.oranges += 2;
  farmer.stock.grapes += 3;
  farmer.stock.watermelons += 1;
  
  // Limpar clientes remanescentes
  customers = [];
  
  // Adicionar novos clientes
  for (let i = 0; i < 3; i++) {
    addCustomer();
  }
}